import requests, pyautogui
import keyboard


def main():
	url = "https://discordapp.com/api/webhooks/719956803479404585/7VhUyTNM23_E-UGGhR2zQ4sPZhgrCP4aRMvay9Y9bT6tNLN41hvoZT_NWYDyTbgj_D6X"
	while True:
		if keyboard.is_pressed('s'):
			image = pyautogui.screenshot()
			image.save("screen.jpg")
			requests.post(url, files={"screenshot": open("screen.jpg", "rb")})
		if keyboard.is_pressed('Esc'):
			requests.post(url, data={"content": "Конец связи"})
			quit()
		if keyboard.is_pressed('l'):
			requests.post(url, data={"content": "Маловато"})
		if keyboard.is_pressed('b'):
			requests.post(url, data={"content": "Не то"})
		if keyboard.is_pressed('n'):
			requests.post(url, data={"content": "Нет"})
		if keyboard.is_pressed('y'):
			requests.post(url, data={"content": "Да"})


if __name__ == '__main__':
	main()
